#!/bin/bash

# Author: Amit Khedkar
# Created: 07th May 2023
# Last Modified: 07th May 2023

# Prerequisit:
# 1) Hadoop services are running
# 2) Your home folder is there on HDFS, Hive ware house is set on hdfs to /user/hive/warehouse
# 3) Hive metastore and Hiveserver2 services are running
# 4) A setLocalPath.sh runs successfully
# 5) A setupEnv.sh runs successfully
# 6) Module 1 run successfully

# Description:
# This script is abstractig module 2 functionality of the project zomato_etl
# It is invoked from wrapper.sh
# 
# Reference - Project SRS doc

# Usage: 
# ./module_2.sh <hive_dbname>

source ./names.properties

Id=mod_2_$(date +"%Y%m%d%H%M%S")
Step=module_2
SSA="NA"
Start_Time=$(date +%R)

dbname=$1

echo "${0} - module_2.sh started---"

# 1) Functionality - Checking running instance of the application
# ToDo 1 - Copy this functionality from module_1.sh here

echo "${0} - Job Start Time is $Start_Time"
echo "${0} - Hive DB Name is $dbname"

# 2) Functionality - Ceating an hive external table default.dim_country with location to /user/talentum/zomato_etl/zomato_ext/dim_country 
# ToDo 2 - Refere the shared ddl scripts and use the appropriate one, note you will use beeline command
echo "${0} - Hive dim_country table created"

# 3) Functionality - 
#	1) Ceating an hive temporary/managed table default.raw_zomato without location clause
#	2) Ceating an hive external partition table default.zomato with location to /user/talentum/zomato_etl/zomato_ext/zomato
# ToDo 3 - Refere the shared ddl scripts and use the appropriate one, note you will use beeline command
echo "${0} - Hive raw_zomato and zomato tables created"

# 4) Functionality - Loading the data into Hive table default.dim_country table from staging area (/home/talentum/proj_zomato/zomato_raw_files)
# ToDo 4 - Create and invoke a hive script dml/loadIntoCountry.hql, note you will use beeline command
echo "${0} - Hive dim_country table populated"

# 5) Functionality - Loading the data from localPrjCsvPath into Hive table default.raw_zomato 
# ToDo 5 - Create and invoke a hive script dml/loadIntoRaw.hive, note you will use beeline command
echo "${0} - Hive raw_zomato table populated"

# 6) Functionality - Inserting records into partition table default.zomato by selecting records from default.raw_zomato 
# ToDo 6- Create and invoke a hive script dml/loadIntoZomato.hive, note you will use beeline command

echo "${0} - Hive zomato table populated"

# 7) Functionality - Preparing log message
STATUS=$?
if [ $STATUS == "0" ]; then
	STATUS="SUCCEEDED"
	echo "${0} - STATUS = $STATUS"
	# Dropping Hive table default.raw_zomato 
	# ToDo 7- Create and invoke a hive script ddl/dropRaw.hive, note you will use beeline command
	
	echo "${0} - Hive default.raw_zomato table dropped"
else
	STATUS="FAILED"
	echo "${0} - STATUS = $STATUS"
	echo "Failed in module 2" | mail -s "Module2" akhedkar@talentumglobal.com
fi

End_Time=$(date +%R)	
echo "${0} - Job End Time is $End_Time"

# 8) Functionality - Adding log message into a log file on local file system
echo $Id","$Step","$SSA","$Start_Time","$End_Time","$STATUS >> $localPrjLogsPath/$logFile.log

# 9) Loading the log file from local file system to Hive table
# Create if not exists temporary/managed table default.zomato_summary_log with location clause /user/talentum/zomato_etl/log
beeline -u jdbc:hive2://localhost:10000/$dbname -n hiveuser -p Hive@123 --hivevar dbname=$dbname -f $localPrjDDLPath/createLogTable.hive
echo "${0} - Hive zomato_summary_log table created if not exists"
# Load logfile into table default.zomato_summary_log
# ToDo 8- Create and invoke a hive script dml/loadIntoLog.hive, note you will use beeline command

echo "${0} - Hive zomato_summary_log table populated"

# 10) Delete the Application running instance
# ToDo 9 - Copy this functionality from module_1.sh here

echo "${0} - removal of the instance of module 2 done"

echo "${0} - module_2.sh ended---"



